:mod:`cola.models.main` -- Main application model
=================================================
Provides access to git data.

.. automodule:: cola.models.main
    :members:
    :undoc-members:
