:mod:`cola.controllers.classic` -- Classic controller
===============================================================
.. automodule:: cola.controllers.classic
    :members:
    :undoc-members:

