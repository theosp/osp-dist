:mod:`cola.resources` -- Resources
==================================
.. automodule:: cola.resources
    :members:
    :undoc-members:
