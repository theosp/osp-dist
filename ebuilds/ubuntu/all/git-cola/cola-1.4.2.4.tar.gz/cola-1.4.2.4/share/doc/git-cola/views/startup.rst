:mod:`cola.views.startup` -- Startup Dialog
===========================================
.. automodule:: cola.views.startup
   :members:
   :undoc-members:
