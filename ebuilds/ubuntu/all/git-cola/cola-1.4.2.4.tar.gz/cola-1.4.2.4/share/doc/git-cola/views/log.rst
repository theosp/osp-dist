:mod:`cola.views.log` -- Log viewer
---------------------------------------------------------------
.. automodule:: cola.views.log
    :members:
    :undoc-members:
