Controllers
===========
.. toctree::

    main
    bookmarks
    compare
    classic
    merge
    options
    remote
    repobrowser
    search
    selectcommits
    stash
