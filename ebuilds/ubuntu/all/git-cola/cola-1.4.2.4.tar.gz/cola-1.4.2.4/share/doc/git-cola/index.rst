.. git-cola documentation master file, created by
   sphinx-quickstart on Sat Apr 18 22:49:53 2009.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

======================
git-cola documentation
======================
.. toctree::

    userguide

Release Notes
=============
.. toctree::
    :maxdepth: 1

    relnotes

Developer Reference
===================
.. toctree::
    :maxdepth: 2

    reference

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
