:mod:`cola.controllers.remote` -- Remote repository operations
---------------------------------------------------------------
.. automodule:: cola.controllers.remote
    :members:
    :undoc-members:
