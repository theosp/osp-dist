==========
User Guide
==========
.. toctree::

    intro
    mainwindow
    tools
    shortcuts
