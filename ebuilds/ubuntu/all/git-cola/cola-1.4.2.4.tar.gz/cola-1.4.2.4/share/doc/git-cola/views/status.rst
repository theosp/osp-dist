:mod:`cola.views.status` -- Status view
---------------------------------------------------------------
.. automodule:: cola.views.status
    :members:
    :undoc-members:
