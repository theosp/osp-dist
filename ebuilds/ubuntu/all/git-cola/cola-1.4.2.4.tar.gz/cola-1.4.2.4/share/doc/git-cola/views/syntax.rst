:mod:`cola.views.syntax` -- Syntax highlighting
---------------------------------------------------------------
.. automodule:: cola.views.syntax
    :members:
    :undoc-members:
