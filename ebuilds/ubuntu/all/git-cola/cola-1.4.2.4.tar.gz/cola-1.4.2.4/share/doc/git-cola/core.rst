:mod:`cola.core` -- Unicode and UNIX helpers
============================================
.. automodule:: cola.core
    :members:
    :undoc-members:
