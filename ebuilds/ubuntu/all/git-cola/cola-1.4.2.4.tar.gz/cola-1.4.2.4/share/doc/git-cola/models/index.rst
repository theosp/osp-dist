Models
======
.. toctree::

    base
    browser
    main
    gitrepo
    observable
    compare
