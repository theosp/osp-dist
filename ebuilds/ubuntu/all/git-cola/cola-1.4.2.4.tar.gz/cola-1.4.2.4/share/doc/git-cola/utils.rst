:mod:`cola.utils` -- Miscellaneous helpers
==========================================
.. automodule:: cola.utils
    :members:
    :undoc-members:
