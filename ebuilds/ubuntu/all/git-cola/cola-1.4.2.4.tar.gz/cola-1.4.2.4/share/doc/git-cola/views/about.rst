:mod:`cola.views.about` -- About dialog
===============================================================
.. automodule:: cola.views.about
   :members:
   :undoc-members:
