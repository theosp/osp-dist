Miscellaneous Utility Modules
=============================
.. toctree::

    core
    diffparse
    difftool
    gitcfg
    git
    gitcmds
    guicmds
    inotify
    resources
    settings
    utils
    qt
    qtutils
    version
