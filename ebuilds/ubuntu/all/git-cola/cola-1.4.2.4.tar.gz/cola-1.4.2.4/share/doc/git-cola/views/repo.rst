:mod:`cola.views.repo` -- Repository tree view
----------------------------------------------
.. automodule:: cola.views.repo
    :members:
    :undoc-members:
