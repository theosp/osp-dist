:mod:`cola.controllers.stash` -- Stash operations
---------------------------------------------------------------
.. automodule:: cola.controllers.stash
    :members:
    :undoc-members:
