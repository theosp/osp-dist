:mod:`cola.gitcfg` -- Interface to git config data
==================================================
.. automodule:: cola.gitcfg
    :members:
    :undoc-members:
