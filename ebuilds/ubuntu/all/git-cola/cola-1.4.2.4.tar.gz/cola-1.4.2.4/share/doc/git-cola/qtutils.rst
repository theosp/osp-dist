:mod:`cola.qtutils` -- Miscellaneous Qt helpers
===============================================
.. automodule:: cola.qtutils
    :members:
    :undoc-members:
