:mod:`cola.models.compare` -- Compare commits model
===================================================
.. automodule:: cola.models.compare
    :members:
    :undoc-members:
