:mod:`cola.controllers.selectcommits` -- Select commits
---------------------------------------------------------------
.. automodule:: cola.controllers.selectcommits
    :members:
    :undoc-members:
