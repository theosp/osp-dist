:mod:`cola.views.revselect` -- Revision Selector
================================================
.. automodule:: cola.views.revselect
    :members:
    :undoc-members:
