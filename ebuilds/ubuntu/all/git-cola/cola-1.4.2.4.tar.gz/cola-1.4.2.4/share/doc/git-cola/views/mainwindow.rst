:mod:`cola.views.mainwindow` -- Main window base class
---------------------------------------------------------------
.. automodule:: cola.views.mainwindow
    :members:
    :undoc-members:
