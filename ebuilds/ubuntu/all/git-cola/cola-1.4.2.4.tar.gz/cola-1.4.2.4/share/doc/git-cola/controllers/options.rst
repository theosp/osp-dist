:mod:`cola.controllers.options` -- Options and preferences
---------------------------------------------------------------
.. automodule:: cola.controllers.options
    :members:
    :undoc-members:
