:mod:`cola.observer` -- Observer base class
===========================================
.. automodule:: cola.observer
    :members:
    :undoc-members:
