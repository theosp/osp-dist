:mod:`cola.models.observable` -- Observable base class
======================================================
.. automodule:: cola.models.observable
    :members:
    :undoc-members:
