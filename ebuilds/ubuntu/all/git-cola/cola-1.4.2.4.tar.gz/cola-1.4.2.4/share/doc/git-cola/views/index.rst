Views
=====
.. toctree::

    about
    actions
    dag
    log
    main
    mainwindow
    repo
    revselect
    standard
    startup
    status
    syntax
