:mod:`cola.views.standard` -- Standard widget base class
===============================================================
.. automodule:: cola.views.standard
   :members:
   :undoc-members:
