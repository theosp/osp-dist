:mod:`cola.observable` -- Observable base class
===============================================
.. automodule:: cola.observable
    :members:
    :undoc-members:
