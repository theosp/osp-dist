:mod:`cola.gitcmds` -- Helper commands for git
==============================================
.. automodule:: cola.gitcmds
    :members:
    :undoc-members:
