:mod:`cola.errors` -- Custom exceptions
=======================================
.. automodule:: cola.errors
    :members:
    :undoc-members:
