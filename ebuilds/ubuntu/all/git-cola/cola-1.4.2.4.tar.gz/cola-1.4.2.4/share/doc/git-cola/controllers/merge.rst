:mod:`cola.controllers.merge` -- Merge operations
---------------------------------------------------------------
.. automodule:: cola.controllers.merge
    :members:
    :undoc-members:
