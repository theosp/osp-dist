:mod:`cola.inotify` -- inotify helpers
======================================
.. automodule:: cola.inotify
    :members:
    :undoc-members:
