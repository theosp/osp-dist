:mod:`cola.controllers.main` -- Main application controller
===============================================================
.. automodule:: cola.controllers.main
    :members:
    :undoc-members:

