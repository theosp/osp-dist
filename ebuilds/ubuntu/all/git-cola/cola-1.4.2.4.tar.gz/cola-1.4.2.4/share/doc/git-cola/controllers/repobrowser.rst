:mod:`cola.controllers.repobrowser` -- Repository browser
---------------------------------------------------------------
.. automodule:: cola.controllers.repobrowser
    :members:
    :undoc-members:
