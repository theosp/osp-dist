:mod:`cola.models.browser` -- RepoBrowser model
===============================================
.. automodule:: cola.models.browser
    :members:
    :undoc-members:
