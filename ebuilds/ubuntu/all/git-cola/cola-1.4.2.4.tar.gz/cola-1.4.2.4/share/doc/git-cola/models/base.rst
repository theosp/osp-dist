:mod:`cola.models.base` -- Serializable model base class
========================================================
.. automodule:: cola.models.base
    :members:
    :undoc-members:
