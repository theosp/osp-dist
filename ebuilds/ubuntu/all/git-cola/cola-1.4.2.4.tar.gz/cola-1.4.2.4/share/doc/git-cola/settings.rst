:mod:`cola.settings` -- Settings manager
========================================
.. automodule:: cola.settings
    :members:
    :undoc-members:
