:mod:`cola.diffparse` -- Diff Parsing and Processing
====================================================
.. automodule:: cola.diffparse
    :members:
    :undoc-members:
