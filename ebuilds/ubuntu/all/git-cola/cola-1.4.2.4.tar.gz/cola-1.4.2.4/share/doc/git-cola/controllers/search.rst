:mod:`cola.controllers.search` -- Search commits
---------------------------------------------------------------
.. automodule:: cola.controllers.search
    :members:
    :undoc-members:
