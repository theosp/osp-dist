Application
===========
:mod:`cola.main` -- Main
------------------------
.. automodule:: cola.main
    :members:
    :undoc-members:

:mod:`cola.app` -- Custom QApplication implementation
-----------------------------------------------------
.. automodule:: cola.app
    :members:
    :undoc-members:
