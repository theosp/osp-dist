:mod:`cola.git` -- Interface to the git command
===============================================
.. automodule:: cola.git
    :members:
    :undoc-members:
