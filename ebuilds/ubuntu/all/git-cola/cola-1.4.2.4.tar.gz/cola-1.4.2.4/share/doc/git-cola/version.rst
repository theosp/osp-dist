:mod:`cola.version` -- Release versioning
=========================================
.. automodule:: cola.version
    :members:
    :undoc-members:
