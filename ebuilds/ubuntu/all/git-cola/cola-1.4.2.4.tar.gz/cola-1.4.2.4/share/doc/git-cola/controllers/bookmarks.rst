:mod:`cola.controllers.bookmark` -- Bookmarks manager
---------------------------------------------------------------
.. automodule:: cola.controllers.bookmark
    :members:
    :undoc-members:
