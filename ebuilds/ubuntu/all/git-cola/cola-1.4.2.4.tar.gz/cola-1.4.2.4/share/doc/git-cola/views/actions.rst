:mod:`cola.views.actions` -- User Actions Dialog
================================================
.. automodule:: cola.views.actions
    :members:
    :undoc-members:
