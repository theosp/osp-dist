:mod:`cola.guicmds` -- GUI Commands
===================================
.. automodule:: cola.guicmds
    :members:
    :undoc-members:
