:mod:`cola.qt` -- Qt Widget
===========================
.. automodule:: cola.qt
    :members:
    :undoc-members:
