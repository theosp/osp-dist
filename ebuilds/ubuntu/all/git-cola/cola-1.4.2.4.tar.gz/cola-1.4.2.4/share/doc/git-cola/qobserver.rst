:mod:`cola.qobserver` -- QObserver base class
=============================================
.. automodule:: cola.qobserver
    :members:
    :undoc-members:
