:mod:`cola.views.main` -- Main window
===============================================================
.. automodule:: cola.views.main
   :members:
   :undoc-members:

