:mod:`cola.controllers.compare` -- Compare commits
---------------------------------------------------------------
.. automodule:: cola.controllers.compare
    :members:
    :undoc-members:
