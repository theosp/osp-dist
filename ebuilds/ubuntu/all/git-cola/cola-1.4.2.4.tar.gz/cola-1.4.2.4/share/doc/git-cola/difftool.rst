:mod:`cola.difftool` -- Difftool helpers
========================================
.. automodule:: cola.difftool
    :members:
    :undoc-members:
