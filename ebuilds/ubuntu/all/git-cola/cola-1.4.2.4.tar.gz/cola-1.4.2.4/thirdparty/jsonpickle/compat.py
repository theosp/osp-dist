try:
    set = set
except NameError:
    from sets import Set as set
    set = set
