# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui/about.ui'
#
# Created: Sun Jan 25 15:25:59 2009
#      by: PyQt4 UI code generator 4.4.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

class Ui_about(object):
    def setupUi(self, about):
        about.setObjectName("about")
        about.resize(280, 420)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Fixed, QtGui.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(about.sizePolicy().hasHeightForWidth())
        about.setSizePolicy(sizePolicy)
        about.setMinimumSize(QtCore.QSize(280, 420))
        about.setMaximumSize(QtCore.QSize(280, 420))
        about.setStyleSheet("QWidget { background-color: white; color: #666; }")
        self.ham = QtGui.QLabel(about)
        self.ham.setGeometry(QtCore.QRect(0, -10, 291, 121))
        self.ham.setPixmap(QtGui.QPixmap("images:logo-cola.png"))
        self.ham.setObjectName("ham")
        self.spam = QtGui.QLabel(about)
        self.spam.setGeometry(QtCore.QRect(10, 110, 261, 261))
        font = QtGui.QFont()
        font.setFamily("Sans Serif")
        font.setPointSize(7)
        font.setWeight(50)
        font.setBold(False)
        self.spam.setFont(font)
        self.spam.setTextFormat(QtCore.Qt.LogText)
        self.spam.setAlignment(QtCore.Qt.AlignLeading|QtCore.Qt.AlignLeft|QtCore.Qt.AlignTop)
        self.spam.setWordWrap(True)
        self.spam.setTextInteractionFlags(QtCore.Qt.TextSelectableByMouse)
        self.spam.setObjectName("spam")
        self.kthx = QtGui.QPushButton(about)
        self.kthx.setGeometry(QtCore.QRect(60, 380, 160, 24))
        self.kthx.setDefault(True)
        self.kthx.setObjectName("kthx")

        self.retranslateUi(about)
        QtCore.QObject.connect(self.kthx, QtCore.SIGNAL("clicked()"), about.accept)
        QtCore.QMetaObject.connectSlotsByName(about)

    def retranslateUi(self, about):
        about.setWindowTitle(QtGui.QApplication.translate("about", "about git cola", None, QtGui.QApplication.UnicodeUTF8))
        self.spam.setText(QtGui.QApplication.translate("about", "git cola: a highly caffeinated git gui v$VERSION\n"
"\n"
"cola is a sweet, carbonated git gui known for its\n"
"sugary flavour and caffeine-inspired features.\n"
"\n"
"\n"
"Copyright (C) 2009 David Aguilar and contributors\n"
"\n"
"This program is free software: you can redistribute it and/or modify\n"
"it under the terms of the GNU General Public License as published by\n"
"the Free Software Foundation, either version 2 of the License, or\n"
"(at your option) any later version.\n"
"\n"
"This program is distributed in the hope that it will be useful,\n"
"but WITHOUT ANY WARRANTY; without even the implied warranty of\n"
"MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.\n"
"See the GNU General Public License for more details.\n"
"\n"
"You should have received a copy of the GNU General Public License\n"
"along with this program.  If not, see http://www.gnu.org/licenses/.\n"
"", None, QtGui.QApplication.UnicodeUTF8))
        self.kthx.setText(QtGui.QApplication.translate("about", "kthx bye", None, QtGui.QApplication.UnicodeUTF8))


if __name__ == "__main__":
    import sys
    app = QtGui.QApplication(sys.argv)
    about = QtGui.QDialog()
    ui = Ui_about()
    ui.setupUi(about)
    about.show()
    sys.exit(app.exec_())

