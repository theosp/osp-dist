# Copyright (c) 2008 David Aguilar
class ColaException(Exception):
    """Base class for all Cola exceptions."""
    pass
