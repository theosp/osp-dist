# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui/commit.ui'
#
# Created: Sun Jan 25 15:25:59 2009
#      by: PyQt4 UI code generator 4.4.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

class Ui_commit(object):
    def setupUi(self, commit):
        commit.setObjectName("commit")
        commit.resize(531, 467)
        self.vboxlayout = QtGui.QVBoxLayout(commit)
        self.vboxlayout.setObjectName("vboxlayout")
        self.splitter = QtGui.QSplitter(commit)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.MinimumExpanding, QtGui.QSizePolicy.MinimumExpanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.splitter.sizePolicy().hasHeightForWidth())
        self.splitter.setSizePolicy(sizePolicy)
        self.splitter.setOrientation(QtCore.Qt.Vertical)
        self.splitter.setHandleWidth(2)
        self.splitter.setObjectName("splitter")
        self.commit_list = QtGui.QListWidget(self.splitter)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.MinimumExpanding, QtGui.QSizePolicy.MinimumExpanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.commit_list.sizePolicy().hasHeightForWidth())
        self.commit_list.setSizePolicy(sizePolicy)
        self.commit_list.setMinimumSize(QtCore.QSize(0, 20))
        font = QtGui.QFont()
        font.setFamily("Monospace")
        self.commit_list.setFont(font)
        self.commit_list.setAlternatingRowColors(True)
        self.commit_list.setSelectionMode(QtGui.QAbstractItemView.ExtendedSelection)
        self.commit_list.setObjectName("commit_list")
        self.commit_text = QtGui.QTextEdit(self.splitter)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.MinimumExpanding, QtGui.QSizePolicy.MinimumExpanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.commit_text.sizePolicy().hasHeightForWidth())
        self.commit_text.setSizePolicy(sizePolicy)
        self.commit_text.setMinimumSize(QtCore.QSize(0, 40))
        font = QtGui.QFont()
        font.setFamily("Monospace")
        font.setPointSize(12)
        self.commit_text.setFont(font)
        self.commit_text.setTabChangesFocus(True)
        self.commit_text.setUndoRedoEnabled(False)
        self.commit_text.setReadOnly(True)
        self.commit_text.setObjectName("commit_text")
        self.vboxlayout.addWidget(self.splitter)
        self.hboxlayout = QtGui.QHBoxLayout()
        self.hboxlayout.setObjectName("hboxlayout")
        self.label = QtGui.QLabel(commit)
        self.label.setObjectName("label")
        self.hboxlayout.addWidget(self.label)
        self.revision = QtGui.QLineEdit(commit)
        self.revision.setObjectName("revision")
        self.hboxlayout.addWidget(self.revision)
        self.vboxlayout.addLayout(self.hboxlayout)
        self.button_box = QtGui.QDialogButtonBox(commit)
        self.button_box.setStandardButtons(QtGui.QDialogButtonBox.Cancel|QtGui.QDialogButtonBox.Ok)
        self.button_box.setObjectName("button_box")
        self.vboxlayout.addWidget(self.button_box)

        self.retranslateUi(commit)
        QtCore.QObject.connect(self.button_box, QtCore.SIGNAL("accepted()"), commit.accept)
        QtCore.QObject.connect(self.button_box, QtCore.SIGNAL("rejected()"), commit.reject)
        QtCore.QMetaObject.connectSlotsByName(commit)
        commit.setTabOrder(self.button_box, self.commit_list)
        commit.setTabOrder(self.commit_list, self.revision)
        commit.setTabOrder(self.revision, self.commit_text)

    def retranslateUi(self, commit):
        self.label.setText(QtGui.QApplication.translate("commit", "Revision Expression:", None, QtGui.QApplication.UnicodeUTF8))


if __name__ == "__main__":
    import sys
    app = QtGui.QApplication(sys.argv)
    commit = QtGui.QDialog()
    ui = Ui_commit()
    ui.setupUi(commit)
    commit.show()
    sys.exit(app.exec_())

