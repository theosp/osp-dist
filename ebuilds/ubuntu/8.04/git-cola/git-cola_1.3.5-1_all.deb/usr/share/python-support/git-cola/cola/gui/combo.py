# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui/combo.ui'
#
# Created: Sun Jan 25 15:25:58 2009
#      by: PyQt4 UI code generator 4.4.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

class Ui_combo(object):
    def setupUi(self, combo):
        combo.setObjectName("combo")
        combo.resize(400, 73)
        self.vboxlayout = QtGui.QVBoxLayout(combo)
        self.vboxlayout.setObjectName("vboxlayout")
        self.items_widget = QtGui.QComboBox(combo)
        self.items_widget.setEditable(True)
        self.items_widget.setObjectName("items_widget")
        self.vboxlayout.addWidget(self.items_widget)
        self.button_box = QtGui.QDialogButtonBox(combo)
        self.button_box.setOrientation(QtCore.Qt.Horizontal)
        self.button_box.setStandardButtons(QtGui.QDialogButtonBox.Cancel|QtGui.QDialogButtonBox.Ok)
        self.button_box.setObjectName("button_box")
        self.vboxlayout.addWidget(self.button_box)

        self.retranslateUi(combo)
        QtCore.QObject.connect(self.button_box, QtCore.SIGNAL("accepted()"), combo.accept)
        QtCore.QObject.connect(self.button_box, QtCore.SIGNAL("rejected()"), combo.reject)
        QtCore.QMetaObject.connectSlotsByName(combo)
        combo.setTabOrder(self.items_widget, self.button_box)

    def retranslateUi(self, combo):
        combo.setWindowTitle(QtGui.QApplication.translate("combo", "Select Branch...", None, QtGui.QApplication.UnicodeUTF8))


if __name__ == "__main__":
    import sys
    app = QtGui.QApplication(sys.argv)
    combo = QtGui.QDialog()
    ui = Ui_combo()
    ui.setupUi(combo)
    combo.show()
    sys.exit(app.exec_())

