# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui/remote.ui'
#
# Created: Sun Jan 25 15:25:59 2009
#      by: PyQt4 UI code generator 4.4.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

class Ui_remote(object):
    def setupUi(self, remote):
        remote.setObjectName("remote")
        remote.resize(550, 512)
        self.vboxlayout = QtGui.QVBoxLayout(remote)
        self.vboxlayout.setObjectName("vboxlayout")
        self.hboxlayout = QtGui.QHBoxLayout()
        self.hboxlayout.setObjectName("hboxlayout")
        self.label = QtGui.QLabel(remote)
        self.label.setObjectName("label")
        self.hboxlayout.addWidget(self.label)
        self.local_branch = QtGui.QLineEdit(remote)
        self.local_branch.setObjectName("local_branch")
        self.hboxlayout.addWidget(self.local_branch)
        self.vboxlayout.addLayout(self.hboxlayout)
        self.local_branches = QtGui.QListWidget(remote)
        self.local_branches.setObjectName("local_branches")
        self.vboxlayout.addWidget(self.local_branches)
        self.hboxlayout1 = QtGui.QHBoxLayout()
        self.hboxlayout1.setObjectName("hboxlayout1")
        self.label_2 = QtGui.QLabel(remote)
        self.label_2.setObjectName("label_2")
        self.hboxlayout1.addWidget(self.label_2)
        self.remotename = QtGui.QLineEdit(remote)
        self.remotename.setObjectName("remotename")
        self.hboxlayout1.addWidget(self.remotename)
        self.vboxlayout.addLayout(self.hboxlayout1)
        self.remotes = QtGui.QListWidget(remote)
        self.remotes.setObjectName("remotes")
        self.vboxlayout.addWidget(self.remotes)
        self.hboxlayout2 = QtGui.QHBoxLayout()
        self.hboxlayout2.setObjectName("hboxlayout2")
        self.label_3 = QtGui.QLabel(remote)
        self.label_3.setObjectName("label_3")
        self.hboxlayout2.addWidget(self.label_3)
        self.remote_branch = QtGui.QLineEdit(remote)
        self.remote_branch.setObjectName("remote_branch")
        self.hboxlayout2.addWidget(self.remote_branch)
        self.vboxlayout.addLayout(self.hboxlayout2)
        self.remote_branches = QtGui.QListWidget(remote)
        self.remote_branches.setObjectName("remote_branches")
        self.vboxlayout.addWidget(self.remote_branches)
        self.hboxlayout3 = QtGui.QHBoxLayout()
        self.hboxlayout3.setObjectName("hboxlayout3")
        self.ffwd_only_checkbox = QtGui.QCheckBox(remote)
        self.ffwd_only_checkbox.setChecked(True)
        self.ffwd_only_checkbox.setObjectName("ffwd_only_checkbox")
        self.hboxlayout3.addWidget(self.ffwd_only_checkbox)
        self.tags_checkbox = QtGui.QCheckBox(remote)
        self.tags_checkbox.setObjectName("tags_checkbox")
        self.hboxlayout3.addWidget(self.tags_checkbox)
        self.rebase_checkbox = QtGui.QCheckBox(remote)
        self.rebase_checkbox.setObjectName("rebase_checkbox")
        self.hboxlayout3.addWidget(self.rebase_checkbox)
        spacerItem = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.hboxlayout3.addItem(spacerItem)
        self.action_button = QtGui.QPushButton(remote)
        self.action_button.setObjectName("action_button")
        self.hboxlayout3.addWidget(self.action_button)
        self.cancel_button = QtGui.QPushButton(remote)
        self.cancel_button.setObjectName("cancel_button")
        self.hboxlayout3.addWidget(self.cancel_button)
        self.vboxlayout.addLayout(self.hboxlayout3)

        self.retranslateUi(remote)
        QtCore.QObject.connect(self.cancel_button, QtCore.SIGNAL("released()"), remote.reject)
        QtCore.QMetaObject.connectSlotsByName(remote)

    def retranslateUi(self, remote):
        remote.setWindowTitle(QtGui.QApplication.translate("remote", "Push", None, QtGui.QApplication.UnicodeUTF8))
        self.label.setText(QtGui.QApplication.translate("remote", "Local Branches", None, QtGui.QApplication.UnicodeUTF8))
        self.label_2.setText(QtGui.QApplication.translate("remote", "Remote", None, QtGui.QApplication.UnicodeUTF8))
        self.label_3.setText(QtGui.QApplication.translate("remote", "Destination Branch", None, QtGui.QApplication.UnicodeUTF8))
        self.ffwd_only_checkbox.setText(QtGui.QApplication.translate("remote", "Fast Forward Only", None, QtGui.QApplication.UnicodeUTF8))
        self.tags_checkbox.setText(QtGui.QApplication.translate("remote", "Include tags", None, QtGui.QApplication.UnicodeUTF8))
        self.rebase_checkbox.setText(QtGui.QApplication.translate("remote", "Rebase", None, QtGui.QApplication.UnicodeUTF8))
        self.action_button.setText(QtGui.QApplication.translate("remote", "Push", None, QtGui.QApplication.UnicodeUTF8))
        self.cancel_button.setText(QtGui.QApplication.translate("remote", "Cancel", None, QtGui.QApplication.UnicodeUTF8))


if __name__ == "__main__":
    import sys
    app = QtGui.QApplication(sys.argv)
    remote = QtGui.QDialog()
    ui = Ui_remote()
    ui.setupUi(remote)
    remote.show()
    sys.exit(app.exec_())

