# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui/branchview.ui'
#
# Created: Sun Jan 25 15:26:00 2009
#      by: PyQt4 UI code generator 4.4.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

class Ui_branchview(object):
    def setupUi(self, branchview):
        branchview.setObjectName("branchview")
        branchview.resize(658, 350)
        self.verticalLayout = QtGui.QVBoxLayout(branchview)
        self.verticalLayout.setSpacing(4)
        self.verticalLayout.setMargin(4)
        self.verticalLayout.setObjectName("verticalLayout")
        self.splitter = QtGui.QSplitter(branchview)
        self.splitter.setOrientation(QtCore.Qt.Vertical)
        self.splitter.setHandleWidth(2)
        self.splitter.setObjectName("splitter")
        self.layoutWidget = QtGui.QWidget(self.splitter)
        self.layoutWidget.setObjectName("layoutWidget")
        self.gridLayout = QtGui.QGridLayout(self.layoutWidget)
        self.gridLayout.setObjectName("gridLayout")
        self.left_combo = QtGui.QComboBox(self.layoutWidget)
        self.left_combo.setObjectName("left_combo")
        self.left_combo.addItem(QtCore.QString())
        self.left_combo.addItem(QtCore.QString())
        self.gridLayout.addWidget(self.left_combo, 0, 0, 1, 1)
        self.right_combo = QtGui.QComboBox(self.layoutWidget)
        self.right_combo.setObjectName("right_combo")
        self.right_combo.addItem(QtCore.QString())
        self.right_combo.addItem(QtCore.QString())
        self.gridLayout.addWidget(self.right_combo, 0, 1, 1, 1)
        self.left_list = QtGui.QListWidget(self.layoutWidget)
        self.left_list.setObjectName("left_list")
        self.gridLayout.addWidget(self.left_list, 1, 0, 1, 1)
        self.right_list = QtGui.QListWidget(self.layoutWidget)
        self.right_list.setObjectName("right_list")
        self.gridLayout.addWidget(self.right_list, 1, 1, 1, 1)
        self.layoutWidget1 = QtGui.QWidget(self.splitter)
        self.layoutWidget1.setObjectName("layoutWidget1")
        self.gridLayout_2 = QtGui.QGridLayout(self.layoutWidget1)
        self.gridLayout_2.setObjectName("gridLayout_2")
        spacerItem = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.gridLayout_2.addItem(spacerItem, 1, 1, 1, 1)
        self.button_compare = QtGui.QPushButton(self.layoutWidget1)
        self.button_compare.setObjectName("button_compare")
        self.gridLayout_2.addWidget(self.button_compare, 1, 2, 1, 1)
        self.button_close = QtGui.QPushButton(self.layoutWidget1)
        self.button_close.setObjectName("button_close")
        self.gridLayout_2.addWidget(self.button_close, 1, 3, 1, 1)
        self.diff_files = QtGui.QTreeWidget(self.layoutWidget1)
        self.diff_files.setObjectName("diff_files")
        self.gridLayout_2.addWidget(self.diff_files, 0, 0, 1, 4)
        self.verticalLayout.addWidget(self.splitter)

        self.retranslateUi(branchview)
        self.right_combo.setCurrentIndex(1)
        QtCore.QObject.connect(self.button_close, QtCore.SIGNAL("clicked()"), branchview.accept)
        QtCore.QMetaObject.connectSlotsByName(branchview)

    def retranslateUi(self, branchview):
        branchview.setWindowTitle(QtGui.QApplication.translate("branchview", "Branch Diff Viewer", None, QtGui.QApplication.UnicodeUTF8))
        self.left_combo.setItemText(0, QtGui.QApplication.translate("branchview", "Local", None, QtGui.QApplication.UnicodeUTF8))
        self.left_combo.setItemText(1, QtGui.QApplication.translate("branchview", "Remote", None, QtGui.QApplication.UnicodeUTF8))
        self.right_combo.setItemText(0, QtGui.QApplication.translate("branchview", "Local", None, QtGui.QApplication.UnicodeUTF8))
        self.right_combo.setItemText(1, QtGui.QApplication.translate("branchview", "Remote", None, QtGui.QApplication.UnicodeUTF8))
        self.button_compare.setText(QtGui.QApplication.translate("branchview", "Compare", None, QtGui.QApplication.UnicodeUTF8))
        self.button_close.setText(QtGui.QApplication.translate("branchview", "Close", None, QtGui.QApplication.UnicodeUTF8))
        self.diff_files.headerItem().setText(0, QtGui.QApplication.translate("branchview", "File Differences", None, QtGui.QApplication.UnicodeUTF8))


if __name__ == "__main__":
    import sys
    app = QtGui.QApplication(sys.argv)
    branchview = QtGui.QDialog()
    ui = Ui_branchview()
    ui.setupUi(branchview)
    branchview.show()
    sys.exit(app.exec_())

