# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui/bookmark.ui'
#
# Created: Sun Jan 25 15:25:59 2009
#      by: PyQt4 UI code generator 4.4.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

class Ui_bookmark(object):
    def setupUi(self, bookmark):
        bookmark.setObjectName("bookmark")
        bookmark.resize(494, 238)
        self.vboxlayout = QtGui.QVBoxLayout(bookmark)
        self.vboxlayout.setObjectName("vboxlayout")
        self.bookmarks = QtGui.QListWidget(bookmark)
        self.bookmarks.setAlternatingRowColors(True)
        self.bookmarks.setSelectionMode(QtGui.QAbstractItemView.ExtendedSelection)
        self.bookmarks.setObjectName("bookmarks")
        self.vboxlayout.addWidget(self.bookmarks)
        self.hboxlayout = QtGui.QHBoxLayout()
        self.hboxlayout.setObjectName("hboxlayout")
        self.button_open = QtGui.QPushButton(bookmark)
        self.button_open.setObjectName("button_open")
        self.hboxlayout.addWidget(self.button_open)
        self.button_delete = QtGui.QPushButton(bookmark)
        self.button_delete.setObjectName("button_delete")
        self.hboxlayout.addWidget(self.button_delete)
        spacerItem = QtGui.QSpacerItem(91, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.hboxlayout.addItem(spacerItem)
        self.button_save = QtGui.QPushButton(bookmark)
        self.button_save.setObjectName("button_save")
        self.hboxlayout.addWidget(self.button_save)
        self.button_cancel = QtGui.QPushButton(bookmark)
        self.button_cancel.setObjectName("button_cancel")
        self.hboxlayout.addWidget(self.button_cancel)
        self.vboxlayout.addLayout(self.hboxlayout)

        self.retranslateUi(bookmark)
        QtCore.QObject.connect(self.button_cancel, QtCore.SIGNAL("clicked()"), bookmark.reject)
        QtCore.QMetaObject.connectSlotsByName(bookmark)

    def retranslateUi(self, bookmark):
        bookmark.setWindowTitle(QtGui.QApplication.translate("bookmark", "Bookmarks", None, QtGui.QApplication.UnicodeUTF8))
        self.button_open.setText(QtGui.QApplication.translate("bookmark", "Open", None, QtGui.QApplication.UnicodeUTF8))
        self.button_delete.setText(QtGui.QApplication.translate("bookmark", "Delete", None, QtGui.QApplication.UnicodeUTF8))
        self.button_save.setText(QtGui.QApplication.translate("bookmark", "Save", None, QtGui.QApplication.UnicodeUTF8))
        self.button_cancel.setText(QtGui.QApplication.translate("bookmark", "Cancel", None, QtGui.QApplication.UnicodeUTF8))


if __name__ == "__main__":
    import sys
    app = QtGui.QApplication(sys.argv)
    bookmark = QtGui.QDialog()
    ui = Ui_bookmark()
    ui.setupUi(bookmark)
    bookmark.show()
    sys.exit(app.exec_())

