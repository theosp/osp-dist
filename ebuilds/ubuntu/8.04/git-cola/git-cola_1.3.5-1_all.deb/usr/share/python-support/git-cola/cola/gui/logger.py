# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui/logger.ui'
#
# Created: Sun Jan 25 15:25:59 2009
#      by: PyQt4 UI code generator 4.4.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

class Ui_logger(object):
    def setupUi(self, logger):
        logger.setObjectName("logger")
        logger.resize(715, 306)
        self.gridlayout = QtGui.QGridLayout(logger)
        self.gridlayout.setMargin(4)
        self.gridlayout.setHorizontalSpacing(4)
        self.gridlayout.setVerticalSpacing(0)
        self.gridlayout.setObjectName("gridlayout")
        self.output_text = QtGui.QTextEdit(logger)
        font = QtGui.QFont()
        font.setFamily("Monospace")
        font.setPointSize(13)
        self.output_text.setFont(font)
        self.output_text.setAcceptDrops(False)
        self.output_text.setTabChangesFocus(True)
        self.output_text.setUndoRedoEnabled(False)
        self.output_text.setReadOnly(True)
        self.output_text.setAcceptRichText(False)
        self.output_text.setTextInteractionFlags(QtCore.Qt.TextSelectableByKeyboard|QtCore.Qt.TextSelectableByMouse)
        self.output_text.setObjectName("output_text")
        self.gridlayout.addWidget(self.output_text, 0, 0, 1, 4)
        self.groupBox = QtGui.QGroupBox(logger)
        self.groupBox.setObjectName("groupBox")
        self.hboxlayout = QtGui.QHBoxLayout(self.groupBox)
        self.hboxlayout.setSpacing(4)
        self.hboxlayout.setContentsMargins(8, 0, 8, 4)
        self.hboxlayout.setObjectName("hboxlayout")
        self.search_text = QtGui.QLineEdit(self.groupBox)
        self.search_text.setObjectName("search_text")
        self.hboxlayout.addWidget(self.search_text)
        self.next_button = QtGui.QPushButton(self.groupBox)
        self.next_button.setObjectName("next_button")
        self.hboxlayout.addWidget(self.next_button)
        self.prev_button = QtGui.QPushButton(self.groupBox)
        self.prev_button.setObjectName("prev_button")
        self.hboxlayout.addWidget(self.prev_button)
        self.gridlayout.addWidget(self.groupBox, 1, 0, 1, 1)
        spacerItem = QtGui.QSpacerItem(217, 24, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.gridlayout.addItem(spacerItem, 1, 1, 1, 1)
        self.clear_button = QtGui.QPushButton(logger)
        self.clear_button.setObjectName("clear_button")
        self.gridlayout.addWidget(self.clear_button, 1, 2, 1, 1)
        self.close_button = QtGui.QPushButton(logger)
        self.close_button.setObjectName("close_button")
        self.gridlayout.addWidget(self.close_button, 1, 3, 1, 1)

        self.retranslateUi(logger)
        QtCore.QObject.connect(self.close_button, QtCore.SIGNAL("released()"), logger.close)
        QtCore.QMetaObject.connectSlotsByName(logger)
        logger.setTabOrder(self.close_button, self.output_text)

    def retranslateUi(self, logger):
        self.groupBox.setTitle(QtGui.QApplication.translate("logger", "Search", None, QtGui.QApplication.UnicodeUTF8))
        self.next_button.setText(QtGui.QApplication.translate("logger", "Next", None, QtGui.QApplication.UnicodeUTF8))
        self.prev_button.setText(QtGui.QApplication.translate("logger", "Previous", None, QtGui.QApplication.UnicodeUTF8))
        self.clear_button.setText(QtGui.QApplication.translate("logger", "Clear", None, QtGui.QApplication.UnicodeUTF8))
        self.close_button.setText(QtGui.QApplication.translate("logger", "Close", None, QtGui.QApplication.UnicodeUTF8))


if __name__ == "__main__":
    import sys
    app = QtGui.QApplication(sys.argv)
    logger = QtGui.QDialog()
    ui = Ui_logger()
    ui.setupUi(logger)
    logger.show()
    sys.exit(app.exec_())

