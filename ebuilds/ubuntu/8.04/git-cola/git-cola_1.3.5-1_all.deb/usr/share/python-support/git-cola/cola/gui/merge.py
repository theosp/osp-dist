# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui/merge.ui'
#
# Created: Sun Jan 25 15:26:00 2009
#      by: PyQt4 UI code generator 4.4.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

class Ui_merge(object):
    def setupUi(self, merge):
        merge.setObjectName("merge")
        merge.resize(673, 339)
        self.vboxlayout = QtGui.QVBoxLayout(merge)
        self.vboxlayout.setObjectName("vboxlayout")
        self.label = QtGui.QLabel(merge)
        self.label.setAlignment(QtCore.Qt.AlignCenter)
        self.label.setObjectName("label")
        self.vboxlayout.addWidget(self.label)
        self.groupBox = QtGui.QGroupBox(merge)
        self.groupBox.setObjectName("groupBox")
        self.gridlayout = QtGui.QGridLayout(self.groupBox)
        self.gridlayout.setSpacing(0)
        self.gridlayout.setContentsMargins(5, 0, 5, 5)
        self.gridlayout.setObjectName("gridlayout")
        self.label_2 = QtGui.QLabel(self.groupBox)
        self.label_2.setObjectName("label_2")
        self.gridlayout.addWidget(self.label_2, 0, 0, 1, 1)
        self.revision = QtGui.QLineEdit(self.groupBox)
        self.revision.setObjectName("revision")
        self.gridlayout.addWidget(self.revision, 0, 1, 1, 2)
        self.radio_local = QtGui.QRadioButton(self.groupBox)
        self.radio_local.setObjectName("radio_local")
        self.gridlayout.addWidget(self.radio_local, 1, 0, 1, 1)
        self.radio_remote = QtGui.QRadioButton(self.groupBox)
        self.radio_remote.setObjectName("radio_remote")
        self.gridlayout.addWidget(self.radio_remote, 1, 1, 1, 1)
        self.radio_tag = QtGui.QRadioButton(self.groupBox)
        self.radio_tag.setObjectName("radio_tag")
        self.gridlayout.addWidget(self.radio_tag, 1, 2, 1, 1)
        self.revision_list = QtGui.QListWidget(self.groupBox)
        self.revision_list.setAlternatingRowColors(True)
        self.revision_list.setObjectName("revision_list")
        self.gridlayout.addWidget(self.revision_list, 2, 0, 1, 3)
        self.vboxlayout.addWidget(self.groupBox)
        self.hboxlayout = QtGui.QHBoxLayout()
        self.hboxlayout.setObjectName("hboxlayout")
        self.button_viz = QtGui.QPushButton(merge)
        self.button_viz.setObjectName("button_viz")
        self.hboxlayout.addWidget(self.button_viz)
        spacerItem = QtGui.QSpacerItem(231, 24, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.hboxlayout.addItem(spacerItem)
        self.checkbox_squash = QtGui.QCheckBox(merge)
        self.checkbox_squash.setObjectName("checkbox_squash")
        self.hboxlayout.addWidget(self.checkbox_squash)
        self.checkbox_commit = QtGui.QCheckBox(merge)
        self.checkbox_commit.setChecked(True)
        self.checkbox_commit.setObjectName("checkbox_commit")
        self.hboxlayout.addWidget(self.checkbox_commit)
        self.button_cancel = QtGui.QPushButton(merge)
        self.button_cancel.setObjectName("button_cancel")
        self.hboxlayout.addWidget(self.button_cancel)
        self.button_merge = QtGui.QPushButton(merge)
        self.button_merge.setObjectName("button_merge")
        self.hboxlayout.addWidget(self.button_merge)
        self.vboxlayout.addLayout(self.hboxlayout)

        self.retranslateUi(merge)
        QtCore.QObject.connect(self.button_cancel, QtCore.SIGNAL("clicked()"), merge.reject)
        QtCore.QMetaObject.connectSlotsByName(merge)

    def retranslateUi(self, merge):
        merge.setWindowTitle(QtGui.QApplication.translate("merge", "Merge", None, QtGui.QApplication.UnicodeUTF8))
        self.label.setText(QtGui.QApplication.translate("merge", "Merge into %s", None, QtGui.QApplication.UnicodeUTF8))
        self.groupBox.setTitle(QtGui.QApplication.translate("merge", "Revision To Merge", None, QtGui.QApplication.UnicodeUTF8))
        self.label_2.setText(QtGui.QApplication.translate("merge", "Revision Expression:", None, QtGui.QApplication.UnicodeUTF8))
        self.radio_local.setText(QtGui.QApplication.translate("merge", "Local Branch", None, QtGui.QApplication.UnicodeUTF8))
        self.radio_remote.setText(QtGui.QApplication.translate("merge", "Tracking Branch", None, QtGui.QApplication.UnicodeUTF8))
        self.radio_tag.setText(QtGui.QApplication.translate("merge", "Tag", None, QtGui.QApplication.UnicodeUTF8))
        self.button_viz.setText(QtGui.QApplication.translate("merge", "Visualize", None, QtGui.QApplication.UnicodeUTF8))
        self.checkbox_squash.setText(QtGui.QApplication.translate("merge", "Squash", None, QtGui.QApplication.UnicodeUTF8))
        self.checkbox_commit.setText(QtGui.QApplication.translate("merge", "Commit", None, QtGui.QApplication.UnicodeUTF8))
        self.button_cancel.setText(QtGui.QApplication.translate("merge", "Cancel", None, QtGui.QApplication.UnicodeUTF8))
        self.button_merge.setText(QtGui.QApplication.translate("merge", "Merge", None, QtGui.QApplication.UnicodeUTF8))


if __name__ == "__main__":
    import sys
    app = QtGui.QApplication(sys.argv)
    merge = QtGui.QDialog()
    ui = Ui_merge()
    ui.setupUi(merge)
    merge.show()
    sys.exit(app.exec_())

