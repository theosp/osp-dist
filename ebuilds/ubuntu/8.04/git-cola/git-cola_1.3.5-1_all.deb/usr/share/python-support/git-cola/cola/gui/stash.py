# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui/stash.ui'
#
# Created: Sun Jan 25 15:26:00 2009
#      by: PyQt4 UI code generator 4.4.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

class Ui_stash(object):
    def setupUi(self, stash):
        stash.setObjectName("stash")
        stash.resize(683, 201)
        self.verticalLayout = QtGui.QVBoxLayout(stash)
        self.verticalLayout.setObjectName("verticalLayout")
        self.stash_list = QtGui.QListWidget(stash)
        self.stash_list.setObjectName("stash_list")
        self.verticalLayout.addWidget(self.stash_list)
        self.horizontalLayout_2 = QtGui.QHBoxLayout()
        self.horizontalLayout_2.setObjectName("horizontalLayout_2")
        self.button_stash_show = QtGui.QPushButton(stash)
        self.button_stash_show.setObjectName("button_stash_show")
        self.horizontalLayout_2.addWidget(self.button_stash_show)
        self.button_stash_save = QtGui.QPushButton(stash)
        self.button_stash_save.setObjectName("button_stash_save")
        self.horizontalLayout_2.addWidget(self.button_stash_save)
        self.button_stash_apply = QtGui.QPushButton(stash)
        self.button_stash_apply.setObjectName("button_stash_apply")
        self.horizontalLayout_2.addWidget(self.button_stash_apply)
        self.verticalLayout.addLayout(self.horizontalLayout_2)
        self.horizontalLayout = QtGui.QHBoxLayout()
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.button_stash_done = QtGui.QPushButton(stash)
        self.button_stash_done.setObjectName("button_stash_done")
        self.horizontalLayout.addWidget(self.button_stash_done)
        self.button_stash_drop = QtGui.QPushButton(stash)
        self.button_stash_drop.setObjectName("button_stash_drop")
        self.horizontalLayout.addWidget(self.button_stash_drop)
        self.button_stash_clear = QtGui.QPushButton(stash)
        self.button_stash_clear.setObjectName("button_stash_clear")
        self.horizontalLayout.addWidget(self.button_stash_clear)
        self.verticalLayout.addLayout(self.horizontalLayout)

        self.retranslateUi(stash)
        QtCore.QObject.connect(self.button_stash_done, QtCore.SIGNAL("clicked()"), stash.accept)
        QtCore.QMetaObject.connectSlotsByName(stash)
        stash.setTabOrder(self.button_stash_save, self.button_stash_show)
        stash.setTabOrder(self.button_stash_show, self.button_stash_apply)
        stash.setTabOrder(self.button_stash_apply, self.button_stash_drop)
        stash.setTabOrder(self.button_stash_drop, self.button_stash_clear)
        stash.setTabOrder(self.button_stash_clear, self.button_stash_done)

    def retranslateUi(self, stash):
        stash.setWindowTitle(QtGui.QApplication.translate("stash", "Stash", None, QtGui.QApplication.UnicodeUTF8))
        self.button_stash_show.setToolTip(QtGui.QApplication.translate("stash", "Show the changes recorded in the selected stash stash as a diff", None, QtGui.QApplication.UnicodeUTF8))
        self.button_stash_show.setText(QtGui.QApplication.translate("stash", "Show", None, QtGui.QApplication.UnicodeUTF8))
        self.button_stash_save.setText(QtGui.QApplication.translate("stash", "Save", None, QtGui.QApplication.UnicodeUTF8))
        self.button_stash_apply.setToolTip(QtGui.QApplication.translate("stash", "Apply the selected stash", None, QtGui.QApplication.UnicodeUTF8))
        self.button_stash_apply.setText(QtGui.QApplication.translate("stash", "Apply", None, QtGui.QApplication.UnicodeUTF8))
        self.button_stash_done.setText(QtGui.QApplication.translate("stash", "Done", None, QtGui.QApplication.UnicodeUTF8))
        self.button_stash_drop.setToolTip(QtGui.QApplication.translate("stash", "Remove the selected stash", None, QtGui.QApplication.UnicodeUTF8))
        self.button_stash_drop.setText(QtGui.QApplication.translate("stash", "Remove", None, QtGui.QApplication.UnicodeUTF8))
        self.button_stash_clear.setToolTip(QtGui.QApplication.translate("stash", "Remove all stashed states", None, QtGui.QApplication.UnicodeUTF8))
        self.button_stash_clear.setText(QtGui.QApplication.translate("stash", "Remove All", None, QtGui.QApplication.UnicodeUTF8))


if __name__ == "__main__":
    import sys
    app = QtGui.QApplication(sys.argv)
    stash = QtGui.QDialog()
    ui = Ui_stash()
    ui.setupUi(stash)
    stash.show()
    sys.exit(app.exec_())

