# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui/items.ui'
#
# Created: Sun Jan 25 15:25:59 2009
#      by: PyQt4 UI code generator 4.4.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

class Ui_items(object):
    def setupUi(self, items):
        items.setObjectName("items")
        items.resize(523, 299)
        self.vboxlayout = QtGui.QVBoxLayout(items)
        self.vboxlayout.setObjectName("vboxlayout")
        self.items_widget = QtGui.QListWidget(items)
        self.items_widget.setObjectName("items_widget")
        self.vboxlayout.addWidget(self.items_widget)
        self.button_box = QtGui.QDialogButtonBox(items)
        self.button_box.setOrientation(QtCore.Qt.Horizontal)
        self.button_box.setStandardButtons(QtGui.QDialogButtonBox.Cancel|QtGui.QDialogButtonBox.Ok)
        self.button_box.setObjectName("button_box")
        self.vboxlayout.addWidget(self.button_box)

        self.retranslateUi(items)
        QtCore.QObject.connect(self.button_box, QtCore.SIGNAL("accepted()"), items.accept)
        QtCore.QObject.connect(self.button_box, QtCore.SIGNAL("rejected()"), items.reject)
        QtCore.QMetaObject.connectSlotsByName(items)
        items.setTabOrder(self.items_widget, self.button_box)

    def retranslateUi(self, items):
        pass


if __name__ == "__main__":
    import sys
    app = QtGui.QApplication(sys.argv)
    items = QtGui.QDialog()
    ui = Ui_items()
    ui.setupUi(items)
    items.show()
    sys.exit(app.exec_())

