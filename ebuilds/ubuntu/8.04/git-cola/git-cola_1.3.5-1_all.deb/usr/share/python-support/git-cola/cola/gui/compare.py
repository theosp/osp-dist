# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui/compare.ui'
#
# Created: Sun Jan 25 15:25:59 2009
#      by: PyQt4 UI code generator 4.4.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

class Ui_compare(object):
    def setupUi(self, compare):
        compare.setObjectName("compare")
        compare.resize(649, 372)
        self.verticalLayout_3 = QtGui.QVBoxLayout(compare)
        self.verticalLayout_3.setObjectName("verticalLayout_3")
        self.horizontalLayout_2 = QtGui.QHBoxLayout()
        self.horizontalLayout_2.setObjectName("horizontalLayout_2")
        self.verticalLayout = QtGui.QVBoxLayout()
        self.verticalLayout.setSpacing(1)
        self.verticalLayout.setObjectName("verticalLayout")
        self.descriptions_start = QtGui.QTreeWidget(compare)
        self.descriptions_start.setRootIsDecorated(False)
        self.descriptions_start.setAllColumnsShowFocus(True)
        self.descriptions_start.setObjectName("descriptions_start")
        self.verticalLayout.addWidget(self.descriptions_start)
        self.revision_start = QtGui.QLineEdit(compare)
        self.revision_start.setReadOnly(True)
        self.revision_start.setObjectName("revision_start")
        self.verticalLayout.addWidget(self.revision_start)
        self.horizontalLayout_2.addLayout(self.verticalLayout)
        self.verticalLayout_2 = QtGui.QVBoxLayout()
        self.verticalLayout_2.setSpacing(1)
        self.verticalLayout_2.setObjectName("verticalLayout_2")
        self.descriptions_end = QtGui.QTreeWidget(compare)
        self.descriptions_end.setRootIsDecorated(False)
        self.descriptions_end.setAllColumnsShowFocus(True)
        self.descriptions_end.setObjectName("descriptions_end")
        self.verticalLayout_2.addWidget(self.descriptions_end)
        self.revision_end = QtGui.QLineEdit(compare)
        self.revision_end.setReadOnly(True)
        self.revision_end.setObjectName("revision_end")
        self.verticalLayout_2.addWidget(self.revision_end)
        self.horizontalLayout_2.addLayout(self.verticalLayout_2)
        self.verticalLayout_3.addLayout(self.horizontalLayout_2)
        self.compare_files = QtGui.QTreeWidget(compare)
        self.compare_files.setAlternatingRowColors(True)
        self.compare_files.setRootIsDecorated(False)
        self.compare_files.setAllColumnsShowFocus(True)
        self.compare_files.setObjectName("compare_files")
        self.verticalLayout_3.addWidget(self.compare_files)
        self.horizontalLayout = QtGui.QHBoxLayout()
        self.horizontalLayout.setSpacing(4)
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.show_versions = QtGui.QCheckBox(compare)
        self.show_versions.setObjectName("show_versions")
        self.horizontalLayout.addWidget(self.show_versions)
        self.label = QtGui.QLabel(compare)
        self.label.setObjectName("label")
        self.horizontalLayout.addWidget(self.label)
        self.num_results = QtGui.QSpinBox(compare)
        self.num_results.setMinimum(1)
        self.num_results.setMaximum(9999)
        self.num_results.setProperty("value", QtCore.QVariant(100))
        self.num_results.setObjectName("num_results")
        self.horizontalLayout.addWidget(self.num_results)
        spacerItem = QtGui.QSpacerItem(128, 14, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem)
        self.button_compare = QtGui.QPushButton(compare)
        self.button_compare.setObjectName("button_compare")
        self.horizontalLayout.addWidget(self.button_compare)
        self.button_close = QtGui.QPushButton(compare)
        self.button_close.setObjectName("button_close")
        self.horizontalLayout.addWidget(self.button_close)
        self.verticalLayout_3.addLayout(self.horizontalLayout)

        self.retranslateUi(compare)
        QtCore.QObject.connect(self.button_close, QtCore.SIGNAL("clicked()"), compare.accept)
        QtCore.QMetaObject.connectSlotsByName(compare)

    def retranslateUi(self, compare):
        compare.setWindowTitle(QtGui.QApplication.translate("compare", "Compare Commits", None, QtGui.QApplication.UnicodeUTF8))
        self.descriptions_start.headerItem().setText(0, QtGui.QApplication.translate("compare", "Start Commit", None, QtGui.QApplication.UnicodeUTF8))
        self.descriptions_end.headerItem().setText(0, QtGui.QApplication.translate("compare", "End Commit", None, QtGui.QApplication.UnicodeUTF8))
        self.compare_files.headerItem().setText(0, QtGui.QApplication.translate("compare", "File Differences", None, QtGui.QApplication.UnicodeUTF8))
        self.show_versions.setText(QtGui.QApplication.translate("compare", "Show Versions", None, QtGui.QApplication.UnicodeUTF8))
        self.label.setText(QtGui.QApplication.translate("compare", "Num Results", None, QtGui.QApplication.UnicodeUTF8))
        self.button_compare.setText(QtGui.QApplication.translate("compare", "Compare", None, QtGui.QApplication.UnicodeUTF8))
        self.button_close.setText(QtGui.QApplication.translate("compare", "Close", None, QtGui.QApplication.UnicodeUTF8))


if __name__ == "__main__":
    import sys
    app = QtGui.QApplication(sys.argv)
    compare = QtGui.QDialog()
    ui = Ui_compare()
    ui.setupUi(compare)
    compare.show()
    sys.exit(app.exec_())

